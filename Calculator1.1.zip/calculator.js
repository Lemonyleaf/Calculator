var results=" ";
var realresults=" ";
var flag= " ";
var key = 0;
function show(){ 
	if(xs2.innerText&&flag){
		results = xs2.innerText;
		flag = 0;
	}
	if (key) {
		if(event.srcElement.innerText.match(/[1-9]/)){
    		results = event.srcElement.innerText;
    		xs1.innerText = results;
   	 		key = 0;
		}
		if (event.srcElement.innerText.match(/[\+\-\*\/]/)){
			results += event.srcElement.innerText;
    		xs1.innerText = results;
    		key = 0;
		}
	}
	else{
		results += event.srcElement.innerText;
    	xs1.innerText = results;
	}
    /*results.color = white;*/
}
function work(){
	var re1=/^[\*|\/|\+|\-].+/;
	var re2=/.+[\*|\/|\+|\-]$/;
	var re3=/[\+\-\*\/]{2}/;
	var re4=/^[*]{15}$/;
 	if(results.match(re1)||results.match(re2)||results.match(re3)||results.match(re4)) {
         xs1.innerText = "Error Input!";
         results = " ";
         return;
     }
    realresults = eval(results);
    xs2.innerText = realresults;
    flag = 1;
    key = 1;
    /*realresults.color = white;*/ 
}
function clean(){
	results = " ";
	realresults=" ";
	xs1.innerText = results;
	xs2.innerText = realresults;
}
function back(){
	var temp = "";
	var i;
	for (i = 0; i < results.length-1; i++) {
		temp += results[i];
	}
	results = temp;
	xs1.innerText = results;
}